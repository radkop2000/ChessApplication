After starting the game, there are 5 option displayed for you
    Play
    GameMode
    Game Replays
    Settings
    Exit

PLAY - after clicking Play there will be another 5 options
    VS Player
        starts a classic game against a player
    VS board.Computer
        starts a classic game against a computer of a difficulty set in settings
    Load MVC.PGN Game
        Loads a MVC.PGN game against a player and lets you continue it
    Situation Builder
        Build any chess situation and play it through
    Back
        Gets you back to menu

GameMode - after clicking GameMode a chess game with a special rule based off of a setting set in settings will start
    there are three modes:
    first one will generate a random piece type and only let you move with that piece type that turn
    second one will generate a random specific piece and only let you play with that piece
    third one will randomly select first or second mode every turn

Game Replays
    Lets you import a MVC.PGN game from clipboard or select a MVC.PGN file and analyze and watch it back

Settings - all the settings are:
    GameMode Animation
        turn on or off the animation in the GameMode
    Dev Mode (developer)
        lets you spawn pieces on the board using the right mouse button
    ComputerDifficulty
        lets you choose the difficulty of the compuer with option being Random, Easy and Cheater
    GameMode
        lets you choose one of the previously mentioned types of the GameMode
    board.Clock
        turn on or off the in game clock counter
    Time on clock
        choose the amount of time each player gets for the game
    




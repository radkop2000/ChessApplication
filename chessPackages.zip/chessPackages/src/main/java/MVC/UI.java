package MVC;

import java.awt.*;

public interface UI {

    public void tilePressed(int x, int y);

    Component getComp();

    boolean getDev();
}
